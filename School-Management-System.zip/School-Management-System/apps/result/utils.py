def score_grade(score):
    if score <= 10:
        return "A"
