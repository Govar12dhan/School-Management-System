default_app_config = "apps.finance.apps.FinanceConfig"
